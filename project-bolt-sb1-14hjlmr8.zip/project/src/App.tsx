import React, { useState } from 'react';
import { Mail, Lock, User, ArrowRight, KeyRound } from 'lucide-react';

type AuthPage = 'login' | 'register' | 'forgot';

function App() {
  const [currentPage, setCurrentPage] = useState<AuthPage>('login');

  const LoginForm = () => (
    <div className="space-y-4 w-full">
      <h2 className="text-2xl font-bold text-center mb-6">تسجيل الدخول</h2>
      <div className="relative">
        <Mail className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
        <input
          type="email"
          placeholder="البريد الإلكتروني"
          className="w-full pl-4 pr-12 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
        />
      </div>
      <div className="relative">
        <Lock className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
        <input
          type="password"
          placeholder="كلمة المرور"
          className="w-full pl-4 pr-12 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
        />
      </div>
      <button className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition duration-200">
        تسجيل الدخول
      </button>
      <div className="flex justify-between text-sm text-blue-600">
        <button onClick={() => setCurrentPage('register')} className="hover:underline">
          إنشاء حساب جديد
        </button>
        <button onClick={() => setCurrentPage('forgot')} className="hover:underline">
          نسيت كلمة المرور؟
        </button>
      </div>
    </div>
  );

  const RegisterForm = () => (
    <div className="space-y-4 w-full">
      <h2 className="text-2xl font-bold text-center mb-6">إنشاء حساب جديد</h2>
      <div className="relative">
        <User className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
        <input
          type="text"
          placeholder="اسم المستخدم"
          className="w-full pl-4 pr-12 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
        />
      </div>
      <div className="relative">
        <Mail className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
        <input
          type="email"
          placeholder="البريد الإلكتروني"
          className="w-full pl-4 pr-12 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
        />
      </div>
      <div className="relative">
        <Lock className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
        <input
          type="password"
          placeholder="كلمة المرور"
          className="w-full pl-4 pr-12 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
        />
      </div>
      <div className="relative">
        <KeyRound className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
        <input
          type="password"
          placeholder="تأكيد كلمة المرور"
          className="w-full pl-4 pr-12 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
        />
      </div>
      <button className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition duration-200">
        إنشاء الحساب
      </button>
      <div className="text-center">
        <button 
          onClick={() => setCurrentPage('login')} 
          className="text-sm text-blue-600 hover:underline inline-flex items-center"
        >
          <ArrowRight className="h-4 w-4 ml-1" />
          العودة لتسجيل الدخول
        </button>
      </div>
    </div>
  );

  const ForgotPasswordForm = () => (
    <div className="space-y-4 w-full">
      <h2 className="text-2xl font-bold text-center mb-6">استعادة كلمة المرور</h2>
      <p className="text-gray-600 text-center mb-4">
        أدخل بريدك الإلكتروني وسنرسل لك رابطاً لإعادة تعيين كلمة المرور
      </p>
      <div className="relative">
        <Mail className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
        <input
          type="email"
          placeholder="البريد الإلكتروني"
          className="w-full pl-4 pr-12 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
        />
      </div>
      <button className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition duration-200">
        إرسال رابط الاستعادة
      </button>
      <div className="text-center">
        <button 
          onClick={() => setCurrentPage('login')} 
          className="text-sm text-blue-600 hover:underline inline-flex items-center"
        >
          <ArrowRight className="h-4 w-4 ml-1" />
          العودة لتسجيل الدخول
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center p-4">
      <div className="bg-white p-8 rounded-xl shadow-lg max-w-md w-full">
        {currentPage === 'login' && <LoginForm />}
        {currentPage === 'register' && <RegisterForm />}
        {currentPage === 'forgot' && <ForgotPasswordForm />}
      </div>
    </div>
  );
}

export default App;